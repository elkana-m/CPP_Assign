/*
Author: Elkana Munganga
Filename: ForceToPower.cpp
Date: 11/17/2021
Class: CSIS 252
Assignment 5

Description:
Parent's class definitions' implementation.
ForceToPower.cpp includes ForceToPower.h and has the 
implementation of all the ForceToPower methods.
*/

#include "ForceToPower.h"
#include <iostream>

using namespace std ;



ForceToPower::ForceToPower() {}

ForceToPower::ForceToPower(double n) 
{
    n = value ;
}

