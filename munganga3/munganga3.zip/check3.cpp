/*
Author: Elkana Munganga
Filename: check3.cpp
Date: 10-24-21
Class: CSIS 252
Assignment 3

Description:
Check3.cpp is a file that include all the
necessary headers needed for input and output. 
It also holds in the struct with two types.

*/

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;


const int arraySize = 10000;
struct measurements
{
	string unitName, typeName;

} ;

