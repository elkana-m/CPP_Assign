/*
Author: Elkana Munganga
Filename: check3.h
Date: 10-24-21
Class: CSIS 252
Assignment 3

Description:
check3.h that simply import check3.cpp

*/

#ifndef _CHECK3_H_
#define _CHECK3_H_

#include "check3.cpp"

#endif