Author: Elkana Munganga 
Due : Friday 01/14/2022
Created: 01/14/2022
Assignment 1

DESCRIPTION
This is a C++ program for assignment 1. The purpose of this program is to convert the infix expression to postfix then evaluate the postfix expression.

To make this possible, I used three different files of which two were provided by the instructor. The file used were as follow:

* main.cpp : implement the main function which consist mostly of calling other functions
* stackType.h : implements the templated stack class
* queueType.h : implements the templated queue class
* token.h : implements the token class. Each part of an infix or postfix expression is a Token.



HOW TO RUN
First type make clean to remove all the .o files and prog. Then type make. Follow the procedure below to compile and run the program.

Step1: make clean

Step2: make

Step3: type ls to see if all the .o files and prog were created. If they exist it means the program works. Then proceed to Step4.

Step4: type prog to run the program.

If the program successfully runs:

- You will receive a message to screen asking to enter a valid arithmetic expression on one line.
- Then try to enter: 1+(2*3) or you can use your own number.
- The program will then evaluate the infix to postfix expression for you.


!!! This program runs successfully, but doesn't give the expected results. Due to restrcitions of submission. I am submitting it as it is, but will get fixed after.